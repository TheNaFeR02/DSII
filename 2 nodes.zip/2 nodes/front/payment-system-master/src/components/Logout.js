import React, { useState } from 'react';
import axios from 'axios';
import '../LoginRegister.css';
import { useHistory } from "react-router-dom";


console.log("Logout Page");
const Logout = () => {
    try {
      localStorage.removeItem('token');
      localStorage.removeItem('eastbankToken');
      localStorage.removeItem('westernbankToken');
      window.location.href = "/";
    } catch (error) {
      // Manejar el error de autenticación
    }
  };

export default Logout;