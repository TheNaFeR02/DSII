import React, { useState, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap'

const APIStatusChecker = () => {
  const [apiStatus, setApiStatus] = useState([]);

  useEffect(() => {
    const checkAPIStatus = async () => {
      const apiEndpoints = [
        { name: 'Payment System API', endpoint: 'http://127.0.0.1:8000/', link: 'http://127.0.0.1:8000/' },
        { name: 'Eastern Bank TransactionsAPI 4040', endpoint: 'http://127.0.0.1:4040/ok/', link: 'http://127.0.0.1:4040/' },
        { name: 'Eastern Bank BalancesAPI 4000', endpoint: 'http://127.0.0.1:4000/ok/', link: 'http://127.0.0.1:4000/' },
        { name: 'Western Bank TransactionsAPI 2020', endpoint: 'http://127.0.0.1:2020/ok/', link: 'http://127.0.0.1:2020/' },
        { name: 'WesternBank BalancesAPI 2000', endpoint: 'http://127.0.0.1:2000/ok/', link: 'http://127.0.0.1:2000/' },
      ];

      const statusPromises = apiEndpoints.map((api) =>
        fetch(api.endpoint)
          .then((response) => ({
            name: api.name,
            link: api.link,
            status: response.ok ? 'Funcionando' : 'No funciona',
          }))
          .catch(() => ({
            name: api.name,
            link: api.link,
            status: 'No funciona',
          }))
      );

      const apiStatuses = await Promise.all(statusPromises);
      setApiStatus(apiStatuses);
    };

    checkAPIStatus();
  }, []);

  return (
    <>
      
      <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <div >
        <h2>Estado de las API:</h2>
          {apiStatus.map((api) => (
            <div key={api.endpoint}>
              <p>
                <strong><a href={api.link}>{api.name}</a></strong>: {api.status}
              </p>
            </div>
          ))}
        </div>
      </div>

    </>

  );

}
export default APIStatusChecker;
