import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../BankAccountInfo.css';
import { useNavigate } from 'react-router-dom';

function BankAccountInfo() {
  const [bankType, setBankType] = useState(''); // Tipo de banco seleccionado
  const [accountInfo, setAccountInfo] = useState(null); // Información de la cuenta obtenida de la API
  const navigate = useNavigate();
  const etoken = localStorage.getItem('eastbankToken');
  const wtoken = localStorage.getItem('westernbankToken');


  useEffect(() => {
    if (etoken) {
      axios.get('http://127.0.0.1:4000/accounts/', {
        headers: {
          Authorization: `Token ${localStorage.getItem('eastbankToken')}`,
        },
      })
        .then((response) => {
          setAccountInfo(response.data); // Actualizar el estado con los datos del historial de transacciones
          console.log(response.data);
        })
        .catch((error) => {
          console.error(error); // Manejar el error según tus necesidades
          // Aquí puedes mostrar un mensaje de error al usuario, redirigirlo a una página de error, etc.
        });
    } else if(wtoken) {
       axios.get('http://127.0.0.1:2000/accounts/', {
      headers: {
        Authorization: `Token ${localStorage.getItem('westernbankToken')}`,
      },
    })
      .then((response) => {
        setAccountInfo(response.data); // Actualizar el estado con los datos del historial de transacciones
        console.log(response.data);
      })
      .catch((error) => {
        console.error(error); // Manejar el error según tus necesidades
        // Aquí puedes mostrar un mensaje de error al usuario, redirigirlo a una página de error, etc.
      });
    }
  }, []);

  
  async function bankLogout() {
    try {
      localStorage.removeItem('eastbankToken');
      localStorage.removeItem('westernbankToken');
      navigate("/bank_login");
      window.location.reload();
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <div className="account-information">
      <h2>Bank Account Information</h2>
      {accountInfo && (
        <div className="account-info">
          <p>Owner: {accountInfo[0].owner}</p>
          <hr />
          <p>Identification ID: {accountInfo[0].identification_id}</p>
          <hr />
          <p>Opening Date: {accountInfo[0].opening_date}</p>
          <hr />
          <p>Cards:</p>
          {accountInfo[0].cards.map((card) => (
            <ul key={card.card_number}>
              <li>Card Number: {card.card_number}</li>
              <li>Card Balance: {card.balance}</li>
              <li>Card Brand: {card.card_brand}</li>
              <li>Card Type: {card.card_type}</li>
              <li>Interest Rate: {card.interest_rate}</li>
              <hr />
            </ul>
          ))}
          <p>Currency: {accountInfo[0].currency}</p>
          <hr />
          <p>Status: {accountInfo[0].status}</p>
          <hr />
          <button onClick={bankLogout}>Logout</button>
        </div>
      )}
    </div>
  );
}

export default BankAccountInfo;
