import { Outlet, Link } from "react-router-dom";
import "../Layout.css"; // Importa el archivo de estilos CSS
import { Nav, Navbar } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap'


function hasToken() {
  const token = localStorage.getItem('token');
  return token !== null && token !== undefined;
}
function hasTokenEBank() {
  const etoken = localStorage.getItem('eastbankToken');
  const wtoken = localStorage.getItem('westernbankToken');
  return (etoken !== null && etoken !== undefined) || (wtoken !== null && wtoken !== undefined);
}

const Layout = () => {
  const isAuthenticated = hasToken(); // Verifica si el usuario está autenticado
  const isBankAuthenticated = hasTokenEBank(); // Verifica si el usuario está autenticado en el EastBank

  return (
    <>
      <div style={{ display: 'inline-flex', justifyContent: 'flex-start', width: '100%' }}>
        <div className="d-flex flex-column flex-shrink-0 p-3 bg-body-tertiary" style={{ width: 280, height: '100vh' }}>
          <Link href="/" className="d-flex align-items-center mb-3 mb-md-0 me-md-auto link-body-emphasis text-decoration-none">
            <svg className="bi pe-none me-2" width="40" height="32"></svg>
            <span className="fs-4">UPayment</span>
          </Link>
          <hr></hr>
          <ul className="nav nav-pills flex-column mb-auto">
            <li className="nav-item">
              <Link to="/" className="nav-link active" aria-current="page">
                <svg className="bi pe-none me-2" width="16" height="16"></svg>
                Home
              </Link>
            </li>
            <li>
              <Link to="/api_status_checker" className="nav-link link-body-emphasis">
                <svg className="bi pe-none me-2" width="16" height="16"></svg>
                Api Status
              </Link>
            </li>

            {isAuthenticated ? (
              <>
                <li>
                  <Link to="/transaction_history" className="nav-link link-body-emphasis">
                    <svg className="bi pe-none me-2" width="16" height="16"></svg>
                    History
                  </Link>
                </li>

                <li>
                  <Link to="/payment_form" className="nav-link link-body-emphasis">
                    <svg className="bi pe-none me-2" width="16" height="16"></svg>
                    Transactions
                  </Link>
                </li>



                <div className="dropdown">
                  <Link to="" className="nav-link link-body-emphasis dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                    <svg className="bi pe-none me-2" width="16" height="16"></svg>
                    Bank
                  </Link>
                  <ul className="dropdown-menu text-small shadow">

                    {isBankAuthenticated ? (
                      <>
                        <li><Link className="dropdown-item" to="/bank_account_info">Information</Link></li>
                        <li><hr className="dropdown-divider"></hr></li>
                      </>
                    ) : (<li><Link className="dropdown-item" to="/bank_login">Login</Link></li>)}


                  </ul>
                </div>
              </>
            ) : (
              <>
                <li className="nav-item">
                  <Link to="/login" className="nav-link link-body-emphasis" aria-current="page">
                    <svg className="bi pe-none me-2" width="16" height="16"></svg>
                    Login
                  </Link>
                </li>

                <li className="nav-item">
                  <Link to="/register" className="nav-link link-body-emphasis" aria-current="page">
                    <svg className="bi pe-none me-2" width="16" height="16"></svg>
                    Register
                  </Link>
                </li>
              </>

            )}
          </ul>
          <hr></hr>

          {isAuthenticated &&
            <div className="dropdown">
              <Link to="/profile" className="d-flex align-items-center link-body-emphasis text-decoration-none dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                <img src="https://github.com/mdo.png" alt="" width="32" height="32" className="rounded-circle me-2"></img>
                <strong>mdo</strong>
              </Link>

              <ul className="dropdown-menu text-small shadow">
                {/* <li><Link className="dropdown-item" to="#">Login</Link></li> */}
                <li><Link className="dropdown-item" to="/profile">Profile</Link></li>
                <li><hr className="dropdown-divider"></hr></li>
                <li><Link className="dropdown-item" to="/logout">Sign out</Link></li>
              </ul>
            </div>
          }

        </div>
        <Outlet />
      </div>

    </>
  );
};

export default Layout;
