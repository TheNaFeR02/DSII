import React, { useState } from 'react';
import axios from 'axios';
import '../LoginRegister.css';



console.log("Reister Page");
const Register = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [password2, setPassword2] = useState('');



  const handleRegister = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/registration/', {
        username: username,
        email: email,
        password1: password,
        password2: password2,
      });
      console.log(response);
      console.log(response.data.key);
      window.location.href = "/login";
      alert("Registro Exitoso")
      // localStorage.setItem('token', response.data.key);
    } catch (error) {
      alert("Error en el registro.")
    }
    
    
  };

  return (

    <div style={{ width: '100%', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <form onSubmit={handleRegister} className='login-register-form'>
        <h2>Register</h2>
        <input
          type="text"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          placeholder="User name"
        />
        <input
          type="text"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="Email"
        />
        <input
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Password"
        />
        <input
          type="password"
          value={password2}
          onChange={(e) => setPassword2(e.target.value)}
          placeholder="Conform password"
        />
        <button type="submit">Sign Up</button>
      </form>
    </div>

  );
};

export default Register;
