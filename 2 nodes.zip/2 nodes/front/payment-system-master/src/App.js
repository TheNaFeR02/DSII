import React from 'react';


const App = () => {
  const isAuthenticated = !!localStorage.getItem('token');

  return ("Hello");
};

export default App;
